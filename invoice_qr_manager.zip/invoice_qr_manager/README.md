# مدير الفواتير عبر QR (Invoice QR Manager)

تطبيق Flutter لإدارة الفواتير: استيراد PDF، استخراج البيانات، توليد QR، حفظ في SQLite، مسح QR، وتصدير PDF يحتوي على QR أعلى الفاتورة.

## بناء APK سحابيًا بدون كمبيوتر (GitHub Actions)
1. أنشئ مستودعًا جديدًا على GitHub وارفع محتوى هذا المجلد كما هو (بما فيه مجلد `.github`).
2. افتح تبويب **Actions** وشغّل **Build Android APK** (أو ادفع أي تعديل على الفرع main).
3. بعد انتهاء البناء افتح التشغيل وحمّل **invoice-qr-manager-apk** من قسم Artifacts.

مجلد `android` يُنشأ تلقائيًا أثناء البناء، وتُضاف صلاحية الكاميرا تلقائيًا.

## التشغيل محليًا
```
flutter create --platforms=android .
flutter pub get
flutter run
```
(أضف صلاحية CAMERA في AndroidManifest.xml إن لم تُضف.)

## هيكل المشروع
- lib/main.dart
- lib/models/invoice_model.dart
- lib/services/pdf_service.dart
- lib/services/database_service.dart
- lib/screens/home_screen.dart
- lib/screens/scan_screen.dart
- lib/screens/invoice_detail_screen.dart

## قراءة الفواتير (نص مدمج + OCR عربي)
1. يقرأ التطبيق النص المدمج في الـ PDF.
2. إذا كان الملف ممسوحًا كصورة، أو فيه نص عربي، أو نقصت بيانات، يحوّل أول 3 صفحات إلى صور ويقرأها بـ Tesseract باللغتين العربية والإنجليزية.
3. تظهر نافذة مراجعة لتعديل البيانات قبل الحفظ (دقة OCR تتأثر بجودة المسح).

ملفات اللغة (ara/eng.traineddata) تُحمَّل تلقائيًا في GitHub Actions. للتشغيل المحلي ضعها يدويًا في `assets/tessdata/`.
