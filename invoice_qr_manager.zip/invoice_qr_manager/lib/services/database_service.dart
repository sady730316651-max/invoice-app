import 'package:path/path.dart' as p;
import 'package:sqflite/sqflite.dart';

import '../models/invoice_model.dart';

class DatabaseService {
  DatabaseService._();
  static final DatabaseService instance = DatabaseService._();

  static const String _table = 'invoices';
  Database? _db;

  Future<Database> get database async {
    return _db ??= await _open();
  }

  Future<Database> _open() async {
    final dbPath = await getDatabasesPath();
    final path = p.join(dbPath, 'invoices.db');
    return openDatabase(
      path,
      version: 1,
      onCreate: (db, version) async {
        await db.execute('''
          CREATE TABLE $_table (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            reference TEXT NOT NULL UNIQUE,
            invoice_number TEXT NOT NULL,
            vendor TEXT NOT NULL,
            total REAL NOT NULL,
            date TEXT NOT NULL,
            qr_data TEXT NOT NULL,
            file_path TEXT NOT NULL,
            created_at TEXT NOT NULL
          )
        ''');
      },
    );
  }

  Future<int> insertInvoice(Invoice invoice) async {
    final db = await database;
    return db.insert(_table, invoice.toMap(),
        conflictAlgorithm: ConflictAlgorithm.abort);
  }

  Future<List<Invoice>> getAllInvoices() async {
    final db = await database;
    final rows = await db.query(_table, orderBy: 'id DESC');
    return rows.map(Invoice.fromMap).toList();
  }

  Future<List<Invoice>> searchInvoices(String query) async {
    final db = await database;
    final like = '%$query%';
    final rows = await db.query(
      _table,
      where: 'invoice_number LIKE ? OR vendor LIKE ? OR reference LIKE ?',
      whereArgs: [like, like, like],
      orderBy: 'id DESC',
    );
    return rows.map(Invoice.fromMap).toList();
  }

  Future<Invoice?> getInvoiceByReference(String reference) async {
    final db = await database;
    final rows = await db.query(
      _table,
      where: 'reference = ?',
      whereArgs: [reference],
      limit: 1,
    );
    if (rows.isEmpty) return null;
    return Invoice.fromMap(rows.first);
  }

  Future<Invoice?> getInvoiceById(int id) async {
    final db = await database;
    final rows = await db.query(
      _table,
      where: 'id = ?',
      whereArgs: [id],
      limit: 1,
    );
    if (rows.isEmpty) return null;
    return Invoice.fromMap(rows.first);
  }

  Future<int> deleteInvoice(int id) async {
    final db = await database;
    return db.delete(_table, where: 'id = ?', whereArgs: [id]);
  }
}
