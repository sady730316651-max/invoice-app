import 'dart:io';
import 'dart:typed_data';
import 'dart:ui' as ui;

import 'package:file_picker/file_picker.dart';
import 'package:flutter_tesseract_ocr/flutter_tesseract_ocr.dart';
import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';
import 'package:pdf/pdf.dart' show PdfPageFormat;
import 'package:pdf/widgets.dart' as pw;
import 'package:printing/printing.dart';
import 'package:qr_flutter/qr_flutter.dart';
import 'package:syncfusion_flutter_pdf/pdf.dart' as sf;

import '../models/invoice_model.dart';

/// البيانات المستخرجة من ملف PDF.
class ExtractedInvoiceData {
  final String invoiceNumber;
  final String vendor;
  final double? total;
  final String date;

  const ExtractedInvoiceData({
    this.invoiceNumber = '',
    this.vendor = '',
    this.total,
    this.date = '',
  });

  bool get isEmpty =>
      invoiceNumber.isEmpty && vendor.isEmpty && total == null && date.isEmpty;
}

class PdfService {
  PdfService._();

  // ---------------------------------------------------------------------
  // استخراج البيانات
  // ---------------------------------------------------------------------

  static bool _hasArabic(String s) => RegExp(r'[\u0600-\u06FF]').hasMatch(s);

  /// يقرأ ملف PDF: من النص المدمج أولًا، ثم OCR (عربي + إنجليزي) للفواتير الممسوحة
  /// أو عندما يكون النص العربي المدمج غير موثوق.
  static Future<ExtractedInvoiceData> extractData(String path) async {
    Uint8List bytes;
    try {
      bytes = await File(path).readAsBytes();
    } catch (_) {
      return const ExtractedInvoiceData();
    }

    String text = '';
    try {
      final document = sf.PdfDocument(inputBytes: bytes);
      try {
        text = sf.PdfTextExtractor(document).extractText();
      } finally {
        document.dispose();
      }
    } catch (_) {
      text = '';
    }

    var data =
        text.trim().isEmpty ? const ExtractedInvoiceData() : parseText(text);

    final needOcr = data.total == null ||
        data.invoiceNumber.isEmpty ||
        data.vendor.isEmpty ||
        data.date.isEmpty ||
        _hasArabic(text);

    if (needOcr) {
      try {
        final ocrText = await _ocrPdf(bytes);
        if (ocrText.trim().isNotEmpty) {
          final ocr = parseText(ocrText);
          // النص العربي المدمج في PDF يأتي غالبًا مقلوبًا/متقطعًا، فنفضّل OCR لاسم المورد.
          final keepTextVendor =
              data.vendor.isNotEmpty && !_hasArabic(data.vendor);
          data = ExtractedInvoiceData(
            invoiceNumber: data.invoiceNumber.isNotEmpty
                ? data.invoiceNumber
                : ocr.invoiceNumber,
            vendor: keepTextVendor
                ? data.vendor
                : (ocr.vendor.isNotEmpty ? ocr.vendor : data.vendor),
            total: data.total ?? ocr.total,
            date: data.date.isNotEmpty ? data.date : ocr.date,
          );
        }
      } catch (_) {
        // فشل OCR: نكتفي بما استخرجناه من النص المدمج.
      }
    }
    return data;
  }

  /// يحوّل أول 3 صفحات إلى صور ويقرأها بـ Tesseract (عربي + إنجليزي).
  static Future<String> _ocrPdf(Uint8List pdfBytes) async {
    final tmpDir = await getTemporaryDirectory();
    final buffer = StringBuffer();
    var index = 0;
    await for (final page
        in Printing.raster(pdfBytes, pages: const [0, 1, 2], dpi: 250)) {
      final png = await page.toPng();
      final imgFile = File(p.join(tmpDir.path,
          'ocr_${DateTime.now().microsecondsSinceEpoch}_$index.png'));
      await imgFile.writeAsBytes(png);
      try {
        final pageText = await FlutterTesseractOcr.extractText(
          imgFile.path,
          language: 'ara+eng',
          args: {'preserve_interword_spaces': '1'},
        );
        buffer.writeln(pageText);
      } finally {
        if (await imgFile.exists()) await imgFile.delete();
      }
      index++;
    }
    return buffer.toString();
  }

  static ExtractedInvoiceData parseText(String rawText) {
    final text = normalizeDigits(rawText);
    return ExtractedInvoiceData(
      invoiceNumber: _findInvoiceNumber(text),
      vendor: _findVendor(text),
      total: _findTotal(text),
      date: _findDate(text),
    );
  }

  /// تحويل الأرقام العربية/الفارسية إلى أرقام لاتينية.
  static String normalizeDigits(String input) {
    const arabic = '٠١٢٣٤٥٦٧٨٩';
    const persian = '۰۱۲۳۴۵۶۷۸۹';
    final sb = StringBuffer();
    for (final rune in input.runes) {
      final ch = String.fromCharCode(rune);
      var i = arabic.indexOf(ch);
      if (i < 0) i = persian.indexOf(ch);
      sb.write(i >= 0 ? i.toString() : ch);
    }
    return sb.toString().replaceAll('٬', ',').replaceAll('٫', '.');
  }

  /// تحويل نص مبلغ إلى رقم (يدعم 1,234.56 و 1.234,56 و 12,50).
  static double? parseAmount(String input) {
    var v = input.trim();
    if (v.isEmpty) return null;
    if (v.contains(',') && v.contains('.')) {
      if (v.lastIndexOf(',') > v.lastIndexOf('.')) {
        v = v.replaceAll('.', '').replaceAll(',', '.');
      } else {
        v = v.replaceAll(',', '');
      }
    } else if (v.contains(',')) {
      final parts = v.split(',');
      if (parts.length == 2 && parts.last.length <= 2) {
        v = '${parts.first}.${parts.last}';
      } else {
        v = v.replaceAll(',', '');
      }
    }
    return double.tryParse(v);
  }

  static String _findInvoiceNumber(String text) {
    const token = r'([A-Za-z0-9][A-Za-z0-9\-_\/]*)';
    final patterns = <RegExp>[
      RegExp(
          r'(?:invoice|inv)\s*(?:no\.?|number|num\.?|#)\s*[:：\-]?\s*' + token,
          caseSensitive: false),
      RegExp(
          r'(?:رقم\s*(?:ال)?فاتورة|(?:ال)?فاتورة\s*(?:(?:ال)?ضريبية\s*)?(?:رقم|#))\s*[:：\-]?\s*' +
              token),
      RegExp(r'invoice\s*[:#]\s*' + token, caseSensitive: false),
      RegExp(r'رقم\s*(?:ال)?(?:مرجع|سند|[اإ]يصال)\s*[:：\-]?\s*' + token),
      RegExp(r'\b(INV[-_\/]?[A-Za-z0-9\-_\/]*\d[A-Za-z0-9\-_\/]*)',
          caseSensitive: false),
    ];
    for (final re in patterns) {
      final m = re.firstMatch(text);
      if (m != null && m.group(1) != null) return m.group(1)!.trim();
    }
    return '';
  }

  static double? _findTotal(String text) {
    const amountPattern = r'([0-9][0-9,]*(?:\.[0-9]+)?)';
    final strong = RegExp(
        r'(?:grand\s*total|total\s*amount|amount\s*due|balance\s*due|total\s*due|المبلغ\s*(?:ال[اأإآ]جمال[يى]|المستحق|الكلي|المطلوب)|المجموع\s*الكلي|ال[اأإآ]جمال[يى](?:\s*الكلي)?|[اأإآ]جمال[يى]|الصاف[يى]|المطلوب\s*دفعه)[^0-9\n]{0,30}' +
            amountPattern,
        caseSensitive: false);
    final weak = RegExp(
        r'(?<![A-Za-z])(?:total|المجموع)[^0-9\n]{0,30}' + amountPattern,
        caseSensitive: false);

    for (final re in [strong, weak]) {
      final matches = re.allMatches(text).toList();
      for (final m in matches.reversed) {
        final v = parseAmount(m.group(1)!);
        if (v != null && v > 0) return v;
      }
    }

    // احتياطي: أكبر رقم عشري في المستند.
    final decimalRe = RegExp(r'\b[0-9][0-9,]*[.,][0-9]{2}\b');
    double? best;
    for (final m in decimalRe.allMatches(text)) {
      final v = parseAmount(m.group(0)!);
      if (v != null && (best == null || v > best)) best = v;
    }
    return best;
  }

  static String _findDate(String text) {
    final ymd = RegExp(r'\b(\d{4})[-/.](\d{1,2})[-/.](\d{1,2})\b');
    final dmy = RegExp(r'\b(\d{1,2})[-/.](\d{1,2})[-/.](\d{4})\b');
    final a = ymd.firstMatch(text);
    final b = dmy.firstMatch(text);

    RegExpMatch? pick;
    if (a != null && b != null) {
      pick = a.start <= b.start ? a : b;
    } else {
      pick = a ?? b;
    }
    if (pick == null) return '';

    int year, month, day;
    if (identical(pick, a)) {
      year = int.parse(pick.group(1)!);
      month = int.parse(pick.group(2)!);
      day = int.parse(pick.group(3)!);
    } else {
      day = int.parse(pick.group(1)!);
      month = int.parse(pick.group(2)!);
      year = int.parse(pick.group(3)!);
      if (month > 12 && day <= 12) {
        final tmp = day;
        day = month;
        month = tmp;
      }
    }
    if (month < 1 || month > 12 || day < 1 || day > 31) return '';
    return '${year.toString().padLeft(4, '0')}-'
        '${month.toString().padLeft(2, '0')}-'
        '${day.toString().padLeft(2, '0')}';
  }

  static String _findVendor(String text) {
    final latinLabel = RegExp(
        r'(?:vendor|supplier|seller|sold\s*by|billed?\s*from|company)\s*[:：\-]\s*([^\n\r]+)',
        caseSensitive: false);
    final arabicLabel = RegExp(
        r'^\s*(?:اسم\s*)?(?:المورد|المحل|المؤسسة|الشركة|البائع|المتجر)\s*[:：\-]?\s*(.+)$',
        multiLine: true);

    for (final re in [latinLabel, arabicLabel]) {
      final m = re.firstMatch(text);
      if (m != null) {
        final v = m.group(1)!.trim();
        if (v.isNotEmpty) return v.length > 80 ? v.substring(0, 80) : v;
      }
    }

    final skip = RegExp(
        r'invoice|receipt|tax|date|tel|phone|فاتورة|ايصال|إيصال|ضريب|التاريخ|رقم|هاتف|جوال|العنوان',
        caseSensitive: false);
    String fallback = '';
    for (final line in text.split(RegExp(r'[\r\n]+'))) {
      final t = line.trim();
      if (t.length < 3 || t.length > 60) continue;
      if (skip.hasMatch(t)) continue;
      if (!RegExp(r'[A-Za-z\u0600-\u06FF]').hasMatch(t)) continue;
      if (_hasArabic(t)) return t;
      if (fallback.isEmpty) fallback = t;
    }
    return fallback;
  }

  // ---------------------------------------------------------------------
  // تخزين الملف
  // ---------------------------------------------------------------------

  /// ينسخ الملف إلى مجلد التطبيق الدائم ويعيد المسار الجديد.
  static Future<String> saveCopy(String sourcePath) async {
    final dir = await getApplicationDocumentsDirectory();
    final invoicesDir = Directory(p.join(dir.path, 'invoices'));
    if (!await invoicesDir.exists()) {
      await invoicesDir.create(recursive: true);
    }
    final name =
        '${DateTime.now().millisecondsSinceEpoch}_${p.basename(sourcePath)}';
    final dest = p.join(invoicesDir.path, name);
    await File(sourcePath).copy(dest);
    return dest;
  }

  static Future<void> deleteStoredFile(String path) async {
    try {
      final f = File(path);
      if (await f.exists()) await f.delete();
    } catch (_) {
      // تجاهل أخطاء الحذف.
    }
  }

  // ---------------------------------------------------------------------
  // QR و PDF
  // ---------------------------------------------------------------------

  /// يولّد صورة PNG لرمز QR.
  static Future<Uint8List> generateQrPng(String data, {int size = 400}) async {
    final painter = QrPainter(
      data: data,
      version: QrVersions.auto,
      errorCorrectionLevel: QrErrorCorrectLevel.M,
      gapless: true,
      emptyColor: const ui.Color(0xFFFFFFFF),
    );
    final ByteData? bytes = await painter.toImageData(
      size.toDouble(),
      format: ui.ImageByteFormat.png,
    );
    if (bytes == null) {
      throw Exception('تعذّر توليد صورة رمز QR');
    }
    return bytes.buffer.asUint8List();
  }

  /// يبني ملف PDF جديدًا من الفاتورة الأصلية مع طباعة رمز QR في أعلى الصفحة الأولى.
  static Future<Uint8List> buildInvoiceWithQr(Invoice invoice) async {
    final qrPng = await generateQrPng(invoice.qrData);
    final file = File(invoice.filePath);

    if (!await file.exists()) {
      return _buildFallbackPdf(invoice, qrPng);
    }

    final bytes = await file.readAsBytes();
    final document = sf.PdfDocument(inputBytes: bytes);
    try {
      final page = document.pages[0];
      final pageSize = page.size;
      const qrSize = 80.0;
      const margin = 12.0;

      final qrRect = ui.Rect.fromLTWH(
        pageSize.width - qrSize - margin,
        margin,
        qrSize,
        qrSize,
      );

      // خلفية بيضاء خلف الرمز لضمان وضوحه.
      page.graphics.drawRectangle(
        brush: sf.PdfSolidBrush(sf.PdfColor(255, 255, 255)),
        bounds: ui.Rect.fromLTWH(
          qrRect.left - 4,
          qrRect.top - 4,
          qrSize + 8,
          qrSize + 8 + 12,
        ),
      );

      page.graphics.drawImage(sf.PdfBitmap(qrPng), qrRect);

      page.graphics.drawString(
        invoice.reference,
        sf.PdfStandardFont(sf.PdfFontFamily.helvetica, 7),
        brush: sf.PdfSolidBrush(sf.PdfColor(0, 0, 0)),
        bounds: ui.Rect.fromLTWH(qrRect.left - 4, qrRect.bottom + 2, qrSize + 8, 10),
        format: sf.PdfStringFormat(alignment: sf.PdfTextAlignment.center),
      );

      final out = await document.save();
      return Uint8List.fromList(out);
    } finally {
      document.dispose();
    }
  }

  /// ملف بديل عند فقدان الملف الأصلي (نص لاتيني فقط لأن الخط الافتراضي لا يدعم العربية).
  static Future<Uint8List> _buildFallbackPdf(
      Invoice invoice, Uint8List qrPng) async {
    final doc = pw.Document();
    final qrImage = pw.MemoryImage(qrPng);

    doc.addPage(
      pw.Page(
        pageFormat: PdfPageFormat.a4,
        build: (context) {
          return pw.Column(
            crossAxisAlignment: pw.CrossAxisAlignment.start,
            children: [
              pw.Align(
                alignment: pw.Alignment.topRight,
                child: pw.Column(
                  children: [
                    pw.Image(qrImage, width: 90, height: 90),
                    pw.Text(invoice.reference,
                        style: const pw.TextStyle(fontSize: 8)),
                  ],
                ),
              ),
              pw.SizedBox(height: 24),
              pw.Text('Invoice No: ${_ascii(invoice.invoiceNumber)}',
                  style: const pw.TextStyle(fontSize: 14)),
              pw.SizedBox(height: 8),
              pw.Text('Date: ${_ascii(invoice.date)}',
                  style: const pw.TextStyle(fontSize: 14)),
              pw.SizedBox(height: 8),
              pw.Text('Total: ${invoice.total.toStringAsFixed(2)}',
                  style: const pw.TextStyle(fontSize: 14)),
              pw.SizedBox(height: 8),
              pw.Text('Reference: ${invoice.reference}',
                  style: const pw.TextStyle(fontSize: 14)),
            ],
          );
        },
      ),
    );
    return doc.save();
  }

  static String _ascii(String input) {
    return input.replaceAll(RegExp(r'[^\x20-\x7E]'), '?');
  }

  static String _safeFileName(Invoice invoice) {
    final base = invoice.invoiceNumber.trim().isEmpty
        ? invoice.reference
        : invoice.invoiceNumber;
    final safe = base.replaceAll(RegExp(r'[^A-Za-z0-9_\-]'), '_');
    return 'invoice_$safe.pdf';
  }

  // ---------------------------------------------------------------------
  // طباعة / حفظ / مشاركة
  // ---------------------------------------------------------------------

  static Future<void> printInvoice(Invoice invoice) async {
    final bytes = await buildInvoiceWithQr(invoice);
    await Printing.layoutPdf(
      onLayout: (format) async => bytes,
      name: _safeFileName(invoice),
    );
  }

  static Future<void> shareInvoice(Invoice invoice) async {
    final bytes = await buildInvoiceWithQr(invoice);
    await Printing.sharePdf(bytes: bytes, filename: _safeFileName(invoice));
  }

  /// يحفظ الملف في مكان يختاره المستخدم. يعيد المسار أو null عند الإلغاء.
  static Future<String?> saveInvoicePdf(Invoice invoice) async {
    final bytes = await buildInvoiceWithQr(invoice);
    return FilePicker.platform.saveFile(
      dialogTitle: 'حفظ الفاتورة مع رمز QR',
      fileName: _safeFileName(invoice),
      bytes: bytes,
      type: FileType.custom,
      allowedExtensions: const ['pdf'],
    );
  }
}
