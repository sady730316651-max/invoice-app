import 'dart:convert';
import 'dart:math';

class Invoice {
  final int? id;
  final String reference;
  final String invoiceNumber;
  final String vendor;
  final double total;
  final String date;
  final String qrData;
  final String filePath;
  final String createdAt;

  const Invoice({
    this.id,
    required this.reference,
    required this.invoiceNumber,
    required this.vendor,
    required this.total,
    required this.date,
    required this.qrData,
    required this.filePath,
    required this.createdAt,
  });

  /// رقم مرجعي فريد للفاتورة.
  static String generateReference() {
    final time =
        DateTime.now().millisecondsSinceEpoch.toRadixString(36).toUpperCase();
    final rnd = Random.secure()
        .nextInt(0xFFFFF)
        .toRadixString(36)
        .toUpperCase()
        .padLeft(4, '0');
    return 'INV-$time-$rnd';
  }

  /// المحتوى الذي يُشفَّر داخل رمز QR.
  static String buildQrData({
    required String reference,
    required String invoiceNumber,
    required String vendor,
    required double total,
    required String date,
  }) {
    return jsonEncode({
      'app': 'invoice_qr',
      'ref': reference,
      'no': invoiceNumber,
      'vendor': vendor,
      'total': total,
      'date': date,
    });
  }

  /// استخراج الرقم المرجعي من نص QR الممسوح.
  static String? extractReference(String raw) {
    try {
      final decoded = jsonDecode(raw);
      if (decoded is Map && decoded['ref'] is String) {
        return decoded['ref'] as String;
      }
    } catch (_) {
      // ليس JSON، نجرب النص الخام.
    }
    final trimmed = raw.trim();
    if (trimmed.startsWith('INV-')) return trimmed;
    return null;
  }

  Invoice copyWith({int? id}) {
    return Invoice(
      id: id ?? this.id,
      reference: reference,
      invoiceNumber: invoiceNumber,
      vendor: vendor,
      total: total,
      date: date,
      qrData: qrData,
      filePath: filePath,
      createdAt: createdAt,
    );
  }

  Map<String, dynamic> toMap() {
    return {
      if (id != null) 'id': id,
      'reference': reference,
      'invoice_number': invoiceNumber,
      'vendor': vendor,
      'total': total,
      'date': date,
      'qr_data': qrData,
      'file_path': filePath,
      'created_at': createdAt,
    };
  }

  factory Invoice.fromMap(Map<String, dynamic> map) {
    return Invoice(
      id: map['id'] as int?,
      reference: map['reference'] as String,
      invoiceNumber: map['invoice_number'] as String,
      vendor: map['vendor'] as String,
      total: (map['total'] as num).toDouble(),
      date: map['date'] as String,
      qrData: map['qr_data'] as String,
      filePath: map['file_path'] as String,
      createdAt: map['created_at'] as String,
    );
  }
}
