import 'package:flutter/material.dart';
import 'package:mobile_scanner/mobile_scanner.dart';

import '../models/invoice_model.dart';
import '../services/database_service.dart';
import 'invoice_detail_screen.dart';

class ScanScreen extends StatefulWidget {
  const ScanScreen({super.key});

  @override
  State<ScanScreen> createState() => _ScanScreenState();
}

class _ScanScreenState extends State<ScanScreen> {
  final MobileScannerController _controller = MobileScannerController(
    detectionSpeed: DetectionSpeed.noDuplicates,
    facing: CameraFacing.back,
    formats: const [BarcodeFormat.qrCode],
  );

  bool _handling = false;
  bool _torchOn = false;

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  Future<void> _resumeScanner() async {
    try {
      await _controller.start();
    } catch (_) {
      // قد يكون المسح يعمل بالفعل.
    }
    _handling = false;
  }

  Future<void> _onDetect(BarcodeCapture capture) async {
    if (_handling) return;

    String? raw;
    for (final barcode in capture.barcodes) {
      final value = barcode.rawValue;
      if (value != null && value.isNotEmpty) {
        raw = value;
        break;
      }
    }
    if (raw == null) return;

    _handling = true;
    try {
      await _controller.stop();
    } catch (_) {}

    Invoice? invoice;
    final reference = Invoice.extractReference(raw);
    if (reference != null) {
      invoice = await DatabaseService.instance.getInvoiceByReference(reference);
    }
    if (!mounted) return;

    if (invoice == null) {
      await showDialog<void>(
        context: context,
        builder: (ctx) => AlertDialog(
          title: const Text('فاتورة غير موجودة'),
          content: Text(
            reference == null
                ? 'هذا الرمز لا يخص تطبيق الفواتير.'
                : 'لم يتم العثور على الفاتورة ذات الرقم المرجعي:\n$reference',
          ),
          actions: [
            FilledButton(
              onPressed: () => Navigator.pop(ctx),
              child: const Text('إعادة المسح'),
            ),
          ],
        ),
      );
      if (mounted) await _resumeScanner();
      return;
    }

    await Navigator.of(context).push(
      MaterialPageRoute(
        builder: (_) => InvoiceDetailScreen(invoice: invoice!),
      ),
    );
    if (mounted) await _resumeScanner();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        title: const Text('مسح رمز الفاتورة'),
        actions: [
          IconButton(
            tooltip: 'الفلاش',
            icon: Icon(_torchOn ? Icons.flash_on : Icons.flash_off),
            onPressed: () async {
              try {
                await _controller.toggleTorch();
                setState(() => _torchOn = !_torchOn);
              } catch (_) {}
            },
          ),
          IconButton(
            tooltip: 'تبديل الكاميرا',
            icon: const Icon(Icons.cameraswitch),
            onPressed: () async {
              try {
                await _controller.switchCamera();
              } catch (_) {}
            },
          ),
        ],
      ),
      body: Stack(
        children: [
          MobileScanner(
            controller: _controller,
            onDetect: _onDetect,
            errorBuilder: (context, error, child) {
              return const Center(
                child: Padding(
                  padding: EdgeInsets.all(24),
                  child: Text(
                    'تعذّر تشغيل الكاميرا.\nتأكد من منح التطبيق إذن الكاميرا.',
                    textAlign: TextAlign.center,
                    style: TextStyle(color: Colors.white, fontSize: 16),
                  ),
                ),
              );
            },
          ),
          Center(
            child: Container(
              width: 250,
              height: 250,
              decoration: BoxDecoration(
                border: Border.all(color: Colors.white, width: 3),
                borderRadius: BorderRadius.circular(16),
              ),
            ),
          ),
          const Positioned(
            left: 16,
            right: 16,
            bottom: 48,
            child: Text(
              'وجّه الكاميرا نحو رمز QR الخاص بالفاتورة',
              textAlign: TextAlign.center,
              style: TextStyle(
                color: Colors.white,
                fontSize: 16,
                shadows: [Shadow(blurRadius: 6, color: Colors.black)],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
