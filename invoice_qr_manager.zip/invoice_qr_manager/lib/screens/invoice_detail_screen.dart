import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:qr_flutter/qr_flutter.dart';

import '../models/invoice_model.dart';
import '../services/database_service.dart';
import '../services/pdf_service.dart';

class InvoiceDetailScreen extends StatefulWidget {
  final Invoice invoice;

  const InvoiceDetailScreen({super.key, required this.invoice});

  @override
  State<InvoiceDetailScreen> createState() => _InvoiceDetailScreenState();
}

class _InvoiceDetailScreenState extends State<InvoiceDetailScreen> {
  bool _busy = false;
  late final bool _fileExists;

  Invoice get invoice => widget.invoice;

  @override
  void initState() {
    super.initState();
    _fileExists = File(invoice.filePath).existsSync();
  }

  void _msg(String text) {
    if (!mounted) return;
    ScaffoldMessenger.of(context)
      ..hideCurrentSnackBar()
      ..showSnackBar(SnackBar(content: Text(text)));
  }

  Future<void> _run(Future<void> Function() action) async {
    setState(() => _busy = true);
    try {
      await action();
    } catch (e) {
      _msg('حدث خطأ: $e');
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _print() => _run(() => PdfService.printInvoice(invoice));

  Future<void> _share() => _run(() => PdfService.shareInvoice(invoice));

  Future<void> _save() => _run(() async {
        final path = await PdfService.saveInvoicePdf(invoice);
        if (path == null) {
          _msg('تم إلغاء الحفظ');
        } else {
          _msg('تم حفظ الملف بنجاح');
        }
      });

  Future<void> _delete() async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('حذف الفاتورة'),
        content: const Text('هل تريد حذف هذه الفاتورة نهائيًا؟'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx, false),
            child: const Text('إلغاء'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(ctx, true),
            child: const Text('حذف'),
          ),
        ],
      ),
    );
    if (ok != true) return;
    await _run(() async {
      if (invoice.id != null) {
        await DatabaseService.instance.deleteInvoice(invoice.id!);
      }
      await PdfService.deleteStoredFile(invoice.filePath);
      if (mounted) Navigator.of(context).pop();
    });
  }

  Widget _row(String label, String value, {bool bold = false}) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SizedBox(
            width: 110,
            child: Text(label, style: const TextStyle(color: Colors.grey)),
          ),
          Expanded(
            child: Text(
              value,
              style: TextStyle(
                fontWeight: bold ? FontWeight.bold : FontWeight.normal,
                fontSize: bold ? 18 : 15,
              ),
            ),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final created = DateTime.tryParse(invoice.createdAt);
    final createdText = created == null
        ? invoice.createdAt
        : '${created.year}-${created.month.toString().padLeft(2, '0')}-'
            '${created.day.toString().padLeft(2, '0')}';

    return Scaffold(
      appBar: AppBar(
        title: const Text('تفاصيل الفاتورة'),
        actions: [
          IconButton(
            tooltip: 'حذف',
            icon: const Icon(Icons.delete_outline),
            onPressed: _busy ? null : _delete,
          ),
        ],
      ),
      body: Column(
        children: [
          if (_busy) const LinearProgressIndicator(),
          Expanded(
            child: ListView(
              padding: const EdgeInsets.all(16),
              children: [
                Center(
                  child: Container(
                    padding: const EdgeInsets.all(12),
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(16),
                      boxShadow: const [
                        BoxShadow(blurRadius: 8, color: Colors.black12),
                      ],
                    ),
                    child: QrImageView(
                      data: invoice.qrData,
                      version: QrVersions.auto,
                      size: 220,
                      backgroundColor: Colors.white,
                    ),
                  ),
                ),
                const SizedBox(height: 12),
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Flexible(
                      child: SelectableText(
                        invoice.reference,
                        textDirection: TextDirection.ltr,
                        style: const TextStyle(
                          fontFamily: 'monospace',
                          fontSize: 13,
                        ),
                      ),
                    ),
                    IconButton(
                      tooltip: 'نسخ الرقم المرجعي',
                      icon: const Icon(Icons.copy, size: 18),
                      onPressed: () async {
                        await Clipboard.setData(
                            ClipboardData(text: invoice.reference));
                        _msg('تم نسخ الرقم المرجعي');
                      },
                    ),
                  ],
                ),
                const SizedBox(height: 8),
                Card(
                  child: Padding(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 16, vertical: 8),
                    child: Column(
                      children: [
                        _row('المورد / المحل', invoice.vendor),
                        const Divider(height: 1),
                        _row('رقم الفاتورة', invoice.invoiceNumber),
                        const Divider(height: 1),
                        _row('التاريخ', invoice.date),
                        const Divider(height: 1),
                        _row('المبلغ الإجمالي', invoice.total.toStringAsFixed(2),
                            bold: true),
                        const Divider(height: 1),
                        _row('تاريخ الإضافة', createdText),
                      ],
                    ),
                  ),
                ),
                if (!_fileExists)
                  Padding(
                    padding: const EdgeInsets.only(top: 8),
                    child: Text(
                      'تنبيه: الملف الأصلي غير موجود، سيتم إنشاء ملف PDF مبسّط عند التصدير.',
                      style: TextStyle(color: Colors.orange.shade800),
                    ),
                  ),
                const SizedBox(height: 16),
                FilledButton.icon(
                  onPressed: _busy ? null : _print,
                  icon: const Icon(Icons.print),
                  label: const Text('طباعة الفاتورة مع QR'),
                ),
                const SizedBox(height: 8),
                FilledButton.tonalIcon(
                  onPressed: _busy ? null : _save,
                  icon: const Icon(Icons.save_alt),
                  label: const Text('حفظ PDF جديد مع QR'),
                ),
                const SizedBox(height: 8),
                OutlinedButton.icon(
                  onPressed: _busy ? null : _share,
                  icon: const Icon(Icons.share),
                  label: const Text('مشاركة / نقل الفاتورة'),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
