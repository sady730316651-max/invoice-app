import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';

import '../models/invoice_model.dart';
import '../services/database_service.dart';
import '../services/pdf_service.dart';
import 'invoice_detail_screen.dart';
import 'scan_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final TextEditingController _searchController = TextEditingController();
  List<Invoice> _invoices = [];
  bool _loading = true;
  bool _importing = false;

  @override
  void initState() {
    super.initState();
    _loadInvoices();
  }

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  void _showMessage(String message) {
    if (!mounted) return;
    ScaffoldMessenger.of(context)
      ..hideCurrentSnackBar()
      ..showSnackBar(SnackBar(content: Text(message)));
  }

  Future<void> _loadInvoices() async {
    try {
      final query = _searchController.text.trim();
      final list = query.isEmpty
          ? await DatabaseService.instance.getAllInvoices()
          : await DatabaseService.instance.searchInvoices(query);
      if (!mounted) return;
      setState(() {
        _invoices = list;
        _loading = false;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() => _loading = false);
      _showMessage('تعذّر تحميل الفواتير: $e');
    }
  }

  Future<void> _importInvoice() async {
    try {
      final result = await FilePicker.platform.pickFiles(
        type: FileType.custom,
        allowedExtensions: const ['pdf'],
        withData: false,
      );
      if (result == null || result.files.isEmpty) return;
      final path = result.files.single.path;
      if (path == null) {
        _showMessage('تعذّر الوصول إلى الملف المحدد');
        return;
      }

      setState(() => _importing = true);
      final extracted = await PdfService.extractData(path);
      if (!mounted) return;
      setState(() => _importing = false);

      if (extracted.isEmpty) {
        _showMessage(
            'لم يتم العثور على نص في الملف، يرجى إدخال البيانات يدويًا');
      }

      final reviewed = await showDialog<ExtractedInvoiceData>(
        context: context,
        barrierDismissible: false,
        builder: (_) => _ReviewDialog(initial: extracted),
      );
      if (reviewed == null || reviewed.total == null) return;

      setState(() => _importing = true);
      final storedPath = await PdfService.saveCopy(path);
      final reference = Invoice.generateReference();
      final qrData = Invoice.buildQrData(
        reference: reference,
        invoiceNumber: reviewed.invoiceNumber,
        vendor: reviewed.vendor,
        total: reviewed.total!,
        date: reviewed.date,
      );

      var invoice = Invoice(
        reference: reference,
        invoiceNumber: reviewed.invoiceNumber,
        vendor: reviewed.vendor,
        total: reviewed.total!,
        date: reviewed.date,
        qrData: qrData,
        filePath: storedPath,
        createdAt: DateTime.now().toIso8601String(),
      );
      final id = await DatabaseService.instance.insertInvoice(invoice);
      invoice = invoice.copyWith(id: id);

      if (!mounted) return;
      setState(() => _importing = false);
      await _loadInvoices();
      _showMessage('تم حفظ الفاتورة وتوليد رمز QR');
      await _openDetail(invoice);
    } catch (e) {
      if (mounted) setState(() => _importing = false);
      _showMessage('حدث خطأ أثناء الاستيراد: $e');
    }
  }

  Future<void> _openDetail(Invoice invoice) async {
    await Navigator.of(context).push(
      MaterialPageRoute(
        builder: (_) => InvoiceDetailScreen(invoice: invoice),
      ),
    );
    await _loadInvoices();
  }

  Future<void> _openScanner() async {
    await Navigator.of(context).push(
      MaterialPageRoute(builder: (_) => const ScanScreen()),
    );
    await _loadInvoices();
  }

  Future<bool> _confirmDelete(Invoice invoice) async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('حذف الفاتورة'),
        content: Text('هل تريد حذف فاتورة "${invoice.vendor}" نهائيًا؟'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx, false),
            child: const Text('إلغاء'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(ctx, true),
            child: const Text('حذف'),
          ),
        ],
      ),
    );
    return ok ?? false;
  }

  Future<void> _deleteInvoice(Invoice invoice) async {
    setState(() => _invoices.removeWhere((i) => i.id == invoice.id));
    try {
      if (invoice.id != null) {
        await DatabaseService.instance.deleteInvoice(invoice.id!);
      }
      await PdfService.deleteStoredFile(invoice.filePath);
      _showMessage('تم حذف الفاتورة');
    } catch (e) {
      _showMessage('تعذّر الحذف: $e');
      await _loadInvoices();
    }
  }

  Widget _buildItem(Invoice invoice) {
    return Dismissible(
      key: ValueKey('invoice_${invoice.id}'),
      direction: DismissDirection.endToStart,
      background: Container(
        margin: const EdgeInsets.symmetric(vertical: 4),
        padding: const EdgeInsets.symmetric(horizontal: 20),
        alignment: AlignmentDirectional.centerEnd,
        decoration: BoxDecoration(
          color: Colors.red.shade400,
          borderRadius: BorderRadius.circular(12),
        ),
        child: const Icon(Icons.delete, color: Colors.white),
      ),
      confirmDismiss: (_) => _confirmDelete(invoice),
      onDismissed: (_) => _deleteInvoice(invoice),
      child: Card(
        child: ListTile(
          leading: const CircleAvatar(child: Icon(Icons.receipt_long)),
          title: Text(
            invoice.vendor,
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
          ),
          subtitle: Text('رقم ${invoice.invoiceNumber} • ${invoice.date}'),
          trailing: Text(
            invoice.total.toStringAsFixed(2),
            style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
          ),
          onTap: () => _openDetail(invoice),
        ),
      ),
    );
  }

  Widget _buildBody() {
    if (_loading) {
      return const Center(child: CircularProgressIndicator());
    }
    if (_invoices.isEmpty) {
      final searching = _searchController.text.trim().isNotEmpty;
      return Center(
        child: Padding(
          padding: const EdgeInsets.all(32),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(
                searching ? Icons.search_off : Icons.receipt_long_outlined,
                size: 72,
                color: Colors.grey,
              ),
              const SizedBox(height: 16),
              Text(
                searching
                    ? 'لا توجد نتائج مطابقة'
                    : 'لا توجد فواتير بعد\nاضغط "استيراد فاتورة" لإضافة أول فاتورة',
                textAlign: TextAlign.center,
                style: const TextStyle(color: Colors.grey, fontSize: 16),
              ),
            ],
          ),
        ),
      );
    }
    return ListView.builder(
      padding: const EdgeInsets.fromLTRB(12, 4, 12, 140),
      itemCount: _invoices.length,
      itemBuilder: (_, i) => _buildItem(_invoices[i]),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('مدير الفواتير'),
        actions: [
          IconButton(
            tooltip: 'مسح QR',
            icon: const Icon(Icons.qr_code_scanner),
            onPressed: _openScanner,
          ),
        ],
      ),
      body: Column(
        children: [
          if (_importing) ...[
            const LinearProgressIndicator(),
            const Padding(
              padding: EdgeInsets.only(top: 8),
              child: Text(
                'جارٍ قراءة الفاتورة... قد يستغرق ذلك بضع ثوانٍ',
                style: TextStyle(color: Colors.grey),
              ),
            ),
          ],
          Padding(
            padding: const EdgeInsets.fromLTRB(12, 12, 12, 8),
            child: TextField(
              controller: _searchController,
              onChanged: (_) => _loadInvoices(),
              decoration: InputDecoration(
                hintText: 'بحث بالمورد أو رقم الفاتورة...',
                prefixIcon: const Icon(Icons.search),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
                suffixIcon: _searchController.text.isEmpty
                    ? null
                    : IconButton(
                        icon: const Icon(Icons.clear),
                        onPressed: () {
                          _searchController.clear();
                          _loadInvoices();
                        },
                      ),
              ),
            ),
          ),
          Expanded(child: _buildBody()),
        ],
      ),
      floatingActionButton: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.end,
        children: [
          FloatingActionButton.small(
            heroTag: 'scan_fab',
            tooltip: 'مسح QR',
            onPressed: _openScanner,
            child: const Icon(Icons.qr_code_scanner),
          ),
          const SizedBox(height: 12),
          FloatingActionButton.extended(
            heroTag: 'import_fab',
            onPressed: _importing ? null : _importInvoice,
            icon: const Icon(Icons.upload_file),
            label: const Text('استيراد فاتورة'),
          ),
        ],
      ),
    );
  }
}

/// نافذة مراجعة وتعديل البيانات المستخرجة قبل الحفظ.
class _ReviewDialog extends StatefulWidget {
  final ExtractedInvoiceData initial;

  const _ReviewDialog({required this.initial});

  @override
  State<_ReviewDialog> createState() => _ReviewDialogState();
}

class _ReviewDialogState extends State<_ReviewDialog> {
  final _formKey = GlobalKey<FormState>();
  late final TextEditingController _number;
  late final TextEditingController _vendor;
  late final TextEditingController _total;
  late final TextEditingController _date;

  @override
  void initState() {
    super.initState();
    _number = TextEditingController(text: widget.initial.invoiceNumber);
    _vendor = TextEditingController(text: widget.initial.vendor);
    _total = TextEditingController(
        text: widget.initial.total?.toStringAsFixed(2) ?? '');
    _date = TextEditingController(text: widget.initial.date);
  }

  @override
  void dispose() {
    _number.dispose();
    _vendor.dispose();
    _total.dispose();
    _date.dispose();
    super.dispose();
  }

  String? _required(String? v, String label) {
    if (v == null || v.trim().isEmpty) return 'أدخل $label';
    return null;
  }

  Future<void> _pickDate() async {
    final initial = DateTime.tryParse(_date.text.trim()) ?? DateTime.now();
    final picked = await showDatePicker(
      context: context,
      initialDate: initial,
      firstDate: DateTime(2000),
      lastDate: DateTime(2100),
    );
    if (picked != null) {
      _date.text = '${picked.year.toString().padLeft(4, '0')}-'
          '${picked.month.toString().padLeft(2, '0')}-'
          '${picked.day.toString().padLeft(2, '0')}';
    }
  }

  void _submit() {
    if (!_formKey.currentState!.validate()) return;
    final total = PdfService.parseAmount(
        PdfService.normalizeDigits(_total.text.trim()));
    Navigator.pop(
      context,
      ExtractedInvoiceData(
        invoiceNumber: _number.text.trim(),
        vendor: _vendor.text.trim(),
        total: total,
        date: _date.text.trim(),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: const Text('مراجعة بيانات الفاتورة'),
      content: SizedBox(
        width: double.maxFinite,
        child: SingleChildScrollView(
          child: Form(
            key: _formKey,
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                const Text(
                  'راجع البيانات المستخرجة وعدّلها عند الحاجة.',
                  style: TextStyle(color: Colors.grey),
                ),
                const SizedBox(height: 12),
                TextFormField(
                  controller: _number,
                  decoration: const InputDecoration(
                    labelText: 'رقم الفاتورة',
                    border: OutlineInputBorder(),
                  ),
                  validator: (v) => _required(v, 'رقم الفاتورة'),
                ),
                const SizedBox(height: 12),
                TextFormField(
                  controller: _vendor,
                  decoration: const InputDecoration(
                    labelText: 'اسم المورد / المحل',
                    border: OutlineInputBorder(),
                  ),
                  validator: (v) => _required(v, 'اسم المورد'),
                ),
                const SizedBox(height: 12),
                TextFormField(
                  controller: _total,
                  keyboardType:
                      const TextInputType.numberWithOptions(decimal: true),
                  decoration: const InputDecoration(
                    labelText: 'المبلغ الإجمالي',
                    border: OutlineInputBorder(),
                  ),
                  validator: (v) {
                    if (v == null || v.trim().isEmpty) {
                      return 'أدخل المبلغ الإجمالي';
                    }
                    final value = PdfService.parseAmount(
                        PdfService.normalizeDigits(v.trim()));
                    if (value == null || value < 0) return 'مبلغ غير صالح';
                    return null;
                  },
                ),
                const SizedBox(height: 12),
                TextFormField(
                  controller: _date,
                  decoration: InputDecoration(
                    labelText: 'التاريخ (yyyy-MM-dd)',
                    border: const OutlineInputBorder(),
                    suffixIcon: IconButton(
                      icon: const Icon(Icons.calendar_month),
                      onPressed: _pickDate,
                    ),
                  ),
                  validator: (v) {
                    final t = v?.trim() ?? '';
                    if (t.isEmpty) return 'أدخل التاريخ';
                    if (!RegExp(r'^\d{4}-\d{2}-\d{2}$').hasMatch(t) ||
                        DateTime.tryParse(t) == null) {
                      return 'الصيغة الصحيحة: 2025-01-31';
                    }
                    return null;
                  },
                ),
              ],
            ),
          ),
        ),
      ),
      actions: [
        TextButton(
          onPressed: () => Navigator.pop(context),
          child: const Text('إلغاء'),
        ),
        FilledButton(
          onPressed: _submit,
          child: const Text('حفظ وتوليد QR'),
        ),
      ],
    );
  }
}
