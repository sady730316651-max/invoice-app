ضع هنا ملفات اللغة: ara.traineddata و eng.traineddata
(تُحمَّل تلقائيًا في GitHub Actions). للتشغيل المحلي حمّلها من:
https://github.com/tesseract-ocr/tessdata_best
